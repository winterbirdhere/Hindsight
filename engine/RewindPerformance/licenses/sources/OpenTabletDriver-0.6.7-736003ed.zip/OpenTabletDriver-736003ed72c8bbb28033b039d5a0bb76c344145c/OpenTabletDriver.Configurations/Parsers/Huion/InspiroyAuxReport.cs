using OpenTabletDriver.Plugin.Tablet;
using OpenTabletDriver.Plugin.Tablet.Wheel;

namespace OpenTabletDriver.Configurations.Parsers.UCLogic
{
    public struct InspiroyAuxReport : IAuxReport, IWheelButtonReport
    {
        public InspiroyAuxReport(byte[] report)
        {
            Raw = report;

            AuxButtons =
            [
                report[4].IsBitSet(0),
                report[4].IsBitSet(1),
                report[4].IsBitSet(2),
                report[4].IsBitSet(3),
                report[4].IsBitSet(4),
                report[4].IsBitSet(5),
                report[4].IsBitSet(6),
                report[4].IsBitSet(7),
                report[5].IsBitSet(0),
                report[5].IsBitSet(1),
                report[5].IsBitSet(2),
                report[5].IsBitSet(3),
                report[5].IsBitSet(5),
                report[5].IsBitSet(6),
                report[5].IsBitSet(7),
                report[6].IsBitSet(0),
                report[6].IsBitSet(1),
                report[6].IsBitSet(2),
                report[6].IsBitSet(3),
            ];

            WheelButtons = [[report[5].IsBitSet(4)]];
        }

        public bool[] AuxButtons { set; get; }
        public bool[][] WheelButtons { set; get; }
        public byte[] Raw { set; get; }
    }
}
