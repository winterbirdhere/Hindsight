# Rust components and license notices

These files accompany Rust code in the MSYS2 UCRT64 Windows libraries rav1e 0.8.1-1, librsvg 2.62.3-1 and libdovi 3.4.0-1. The matching Windows library and Rust toolchain notices are included. The source companion is Hindsight-FFmpeg-MSYS2-Rust-Sources-and-Notices.zip.

The table preserves the published Cargo license expressions. Each package's original notice files appear under crates/. For packages that published their declaration or source header in place of a standalone license, supplemental/ includes the original declarations and available upstream texts. Full standard license references are included there. The source inventory also includes certain build-time inputs.

| Rust crate | Version | Declared license |
| --- | --- | --- |
| addr2line | 0.24.2 | Apache-2.0 OR MIT |
| addr2line | 0.25.1 | Apache-2.0 OR MIT |
| adler2 | 2.0.0 | 0BSD OR MIT OR Apache-2.0 |
| adler2 | 2.0.1 | 0BSD OR MIT OR Apache-2.0 |
| aho-corasick | 1.1.4 | Unlicense OR MIT |
| aligned | 0.4.2 | MIT OR Apache-2.0 |
| aligned-vec | 0.6.4 | MIT |
| allocator-api2 | 0.2.21 | MIT OR Apache-2.0 |
| anstream | 0.6.19 | MIT OR Apache-2.0 |
| anstyle | 1.0.11 | MIT OR Apache-2.0 |
| anstyle-parse | 0.2.7 | MIT OR Apache-2.0 |
| anstyle-query | 1.1.3 | MIT OR Apache-2.0 |
| anstyle-wincon | 3.0.9 | MIT OR Apache-2.0 |
| anyhow | 1.0.102 | MIT OR Apache-2.0 |
| anyhow | 1.0.98 | MIT OR Apache-2.0 |
| approx | 0.5.1 | Apache-2.0 |
| arg_enum_proc_macro | 0.3.4 | MIT |
| arrayvec | 0.7.6 | MIT OR Apache-2.0 |
| as-slice | 0.2.1 | MIT OR Apache-2.0 |
| autocfg | 1.4.0 | Apache-2.0 OR MIT |
| autocfg | 1.5.0 | Apache-2.0 OR MIT |
| av-metrics | 0.9.1 | MIT |
| av-scenechange | 0.14.1 | MIT |
| av1-grain | 0.2.4 | BSD-2-Clause |
| bitflags | 2.10.0 | MIT OR Apache-2.0 |
| bitflags | 2.9.1 | MIT OR Apache-2.0 |
| bitstream-io | 4.10.0 | MIT/Apache-2.0 |
| bitstream-io | 4.2.0 | MIT/Apache-2.0 |
| bitvec | 1.0.1 | MIT |
| bitvec_helpers | 4.0.2 | MIT |
| built | 0.8.0 | MIT |
| bytemuck | 1.24.0 | Zlib OR Apache-2.0 OR MIT |
| byteorder | 1.5.0 | Unlicense OR MIT |
| byteorder-lite | 0.1.0 | Unlicense OR MIT |
| cairo-rs | 0.22.0 | MIT |
| cairo-sys-rs | 0.22.0 | MIT |
| cast | 0.3.0 | MIT OR Apache-2.0 |
| cc | 1.2.0 | MIT OR Apache-2.0 |
| cc | 1.2.26 | MIT OR Apache-2.0 |
| cfg-expr | 0.20.6 | MIT OR Apache-2.0 |
| cfg-if | 1.0.0 | MIT/Apache-2.0 |
| cfg-if | 1.0.1 | MIT OR Apache-2.0 |
| cfg-if | 1.0.4 | MIT OR Apache-2.0 |
| clap | 4.5.40 | MIT OR Apache-2.0 |
| clap_builder | 4.5.40 | MIT OR Apache-2.0 |
| clap_complete | 4.5.54 | MIT OR Apache-2.0 |
| clap_derive | 4.5.40 | MIT OR Apache-2.0 |
| clap_lex | 0.7.5 | MIT OR Apache-2.0 |
| color_quant | 1.1.0 | MIT |
| colorchoice | 1.0.4 | MIT OR Apache-2.0 |
| compiler_builtins | 0.1.152 | MIT AND Apache-2.0 WITH LLVM-exception AND (MIT OR Apache-2.0) |
| console | 0.15.11 | MIT |
| core2 | 0.4.0 | Apache-2.0 OR MIT |
| crc | 3.4.0 | MIT OR Apache-2.0 |
| crc-catalog | 2.5.0 | MIT OR Apache-2.0 |
| crc32fast | 1.5.0 | MIT OR Apache-2.0 |
| crossbeam | 0.8.4 | MIT OR Apache-2.0 |
| crossbeam-channel | 0.5.15 | MIT OR Apache-2.0 |
| crossbeam-deque | 0.8.6 | MIT OR Apache-2.0 |
| crossbeam-epoch | 0.9.18 | MIT OR Apache-2.0 |
| crossbeam-queue | 0.3.12 | MIT OR Apache-2.0 |
| crossbeam-utils | 0.8.21 | MIT OR Apache-2.0 |
| cssparser | 0.35.0 | MPL-2.0 |
| cssparser-color | 0.3.0 | MPL-2.0 |
| cssparser-macros | 0.6.1 | MPL-2.0 |
| data-url | 0.3.2 | MIT OR Apache-2.0 |
| derive_more | 2.1.1 | MIT |
| derive_more-impl | 2.1.1 | MIT |
| displaydoc | 0.2.5 | MIT OR Apache-2.0 |
| dtoa | 1.0.11 | MIT OR Apache-2.0 |
| dtoa-short | 0.3.5 | MPL-2.0 |
| either | 1.15.0 | MIT OR Apache-2.0 |
| encode_unicode | 1.0.0 | Apache-2.0 OR MIT |
| encoding_rs | 0.8.35 | (Apache-2.0 OR MIT) AND BSD-3-Clause |
| equator | 0.4.2 | MIT |
| equator-macro | 0.4.2 | MIT |
| equivalent | 1.0.2 | Apache-2.0 OR MIT |
| fdeflate | 0.3.7 | MIT OR Apache-2.0 |
| fern | 0.7.1 | MIT |
| flate2 | 1.1.8 | MIT OR Apache-2.0 |
| float-cmp | 0.10.0 | MIT |
| foldhash | 0.2.0 | Zlib |
| form_urlencoded | 1.2.1 | MIT OR Apache-2.0 |
| form_urlencoded | 1.2.2 | MIT OR Apache-2.0 |
| funty | 2.0.0 | MIT |
| futf | 0.1.5 | MIT / Apache-2.0 |
| futures-channel | 0.3.31 | MIT OR Apache-2.0 |
| futures-core | 0.3.32 | MIT OR Apache-2.0 |
| futures-executor | 0.3.31 | MIT OR Apache-2.0 |
| futures-io | 0.3.31 | MIT OR Apache-2.0 |
| futures-macro | 0.3.32 | MIT OR Apache-2.0 |
| futures-task | 0.3.32 | MIT OR Apache-2.0 |
| futures-util | 0.3.32 | MIT OR Apache-2.0 |
| fxhash | 0.2.1 | Apache-2.0/MIT |
| gdk-pixbuf | 0.22.0 | MIT |
| gdk-pixbuf-sys | 0.22.0 | MIT |
| getrandom | 0.3.3 | MIT OR Apache-2.0 |
| gif | 0.14.1 | MIT OR Apache-2.0 |
| gimli | 0.31.1 | MIT OR Apache-2.0 |
| gimli | 0.32.3 | MIT OR Apache-2.0 |
| gio | 0.22.1 | MIT |
| gio-sys | 0.22.0 | MIT |
| git2 | 0.20.2 | MIT OR Apache-2.0 |
| glib | 0.22.0 | MIT |
| glib-macros | 0.22.0 | MIT |
| glib-sys | 0.22.0 | MIT |
| gobject-sys | 0.22.0 | MIT |
| hashbrown | 0.15.2 | MIT OR Apache-2.0 |
| hashbrown | 0.16.1 | MIT OR Apache-2.0 |
| hashbrown | 0.17.1 | MIT OR Apache-2.0 |
| heck | 0.5.0 | MIT OR Apache-2.0 |
| icu_collections | 2.0.0 | Unicode-3.0 |
| icu_collections | 2.1.1 | Unicode-3.0 |
| icu_locale_core | 2.0.0 | Unicode-3.0 |
| icu_locale_core | 2.1.1 | Unicode-3.0 |
| icu_normalizer | 2.0.0 | Unicode-3.0 |
| icu_normalizer | 2.1.1 | Unicode-3.0 |
| icu_normalizer_data | 2.0.0 | Unicode-3.0 |
| icu_normalizer_data | 2.1.1 | Unicode-3.0 |
| icu_properties | 2.0.1 | Unicode-3.0 |
| icu_properties | 2.1.2 | Unicode-3.0 |
| icu_properties_data | 2.0.1 | Unicode-3.0 |
| icu_properties_data | 2.1.2 | Unicode-3.0 |
| icu_provider | 2.0.0 | Unicode-3.0 |
| icu_provider | 2.1.1 | Unicode-3.0 |
| idna | 1.0.3 | MIT OR Apache-2.0 |
| idna | 1.1.0 | MIT OR Apache-2.0 |
| idna_adapter | 1.2.1 | Apache-2.0 OR MIT |
| image | 0.25.10 | MIT OR Apache-2.0 |
| image-webp | 0.2.4 | MIT OR Apache-2.0 |
| indexmap | 2.14.0 | Apache-2.0 OR MIT |
| is_terminal_polyfill | 1.70.1 | MIT OR Apache-2.0 |
| itertools | 0.10.5 | MIT/Apache-2.0 |
| itertools | 0.14.0 | MIT OR Apache-2.0 |
| itoa | 1.0.17 | MIT OR Apache-2.0 |
| itoa | 1.0.18 | MIT OR Apache-2.0 |
| jobserver | 0.1.33 | MIT OR Apache-2.0 |
| lab | 0.11.0 | MIT |
| language-tags | 0.3.2 | MIT/Apache-2.0 |
| lazy_static | 1.5.0 | MIT OR Apache-2.0 |
| libc | 0.2.171 | MIT OR Apache-2.0 |
| libc | 0.2.172 | MIT OR Apache-2.0 |
| libc | 0.2.180 | MIT OR Apache-2.0 |
| libc | 0.2.183 | MIT OR Apache-2.0 |
| libc | 0.2.185 | MIT OR Apache-2.0 |
| libc | 0.2.186 | MIT OR Apache-2.0 |
| libgit2-sys | 0.18.1+1.9.0 | MIT OR Apache-2.0 |
| libz-sys | 1.1.22 | MIT OR Apache-2.0 |
| litemap | 0.8.0 | Unicode-3.0 |
| litemap | 0.8.1 | Unicode-3.0 |
| locale_config | 0.3.0 | MIT |
| lock_api | 0.4.14 | MIT OR Apache-2.0 |
| log | 0.4.27 | MIT OR Apache-2.0 |
| log | 0.4.29 | MIT OR Apache-2.0 |
| mac | 0.1.1 | MIT/Apache-2.0 |
| markup5ever | 0.35.0 | MIT OR Apache-2.0 |
| matrixmultiply | 0.3.10 | MIT/Apache-2.0 |
| maybe-rayon | 0.1.1 | MIT |
| memchr | 2.7.4 | Unlicense OR MIT |
| memchr | 2.7.5 | Unlicense OR MIT |
| memchr | 2.7.6 | Unlicense OR MIT |
| memchr | 2.8.0 | Unlicense OR MIT |
| minimal-lexical | 0.2.1 | MIT/Apache-2.0 |
| miniz_oxide | 0.8.3 | MIT OR Zlib OR Apache-2.0 |
| miniz_oxide | 0.8.9 | MIT OR Zlib OR Apache-2.0 |
| moxcms | 0.8.1 | BSD-3-Clause OR Apache-2.0 |
| mutants | 0.0.3 | MIT |
| nalgebra | 0.34.1 | Apache-2.0 |
| nalgebra-macros | 0.3.0 | Apache-2.0 |
| nasm-rs | 0.3.0 | MIT OR Apache-2.0 |
| new_debug_unreachable | 1.0.6 | MIT |
| no_std_io2 | 0.9.4 | Apache-2.0 OR MIT |
| nom | 7.1.3 | MIT |
| nom | 8.0.0 | MIT |
| noop_proc_macro | 0.3.0 | MIT |
| num-bigint | 0.4.6 | MIT OR Apache-2.0 |
| num-complex | 0.4.6 | MIT OR Apache-2.0 |
| num-derive | 0.4.2 | MIT OR Apache-2.0 |
| num-integer | 0.1.46 | MIT OR Apache-2.0 |
| num-rational | 0.4.2 | MIT OR Apache-2.0 |
| num-traits | 0.2.19 | MIT OR Apache-2.0 |
| object | 0.36.7 | Apache-2.0 OR MIT |
| object | 0.37.3 | Apache-2.0 OR MIT |
| once_cell | 1.21.3 | MIT OR Apache-2.0 |
| once_cell_polyfill | 1.70.1 | MIT OR Apache-2.0 |
| pango | 0.22.0 | MIT |
| pango-sys | 0.22.0 | MIT |
| pangocairo | 0.22.0 | MIT |
| pangocairo-sys | 0.22.0 | MIT |
| parking_lot | 0.12.5 | MIT OR Apache-2.0 |
| parking_lot_core | 0.9.12 | MIT OR Apache-2.0 |
| paste | 1.0.15 | MIT OR Apache-2.0 |
| pastey | 0.1.0 | MIT OR Apache-2.0 |
| percent-encoding | 2.3.1 | MIT OR Apache-2.0 |
| percent-encoding | 2.3.2 | MIT OR Apache-2.0 |
| phf | 0.11.3 | MIT |
| phf_codegen | 0.11.3 | MIT |
| phf_generator | 0.11.3 | MIT |
| phf_macros | 0.11.3 | MIT |
| phf_shared | 0.11.3 | MIT |
| phf_shared | 0.13.1 | MIT |
| pin-project-lite | 0.2.16 | Apache-2.0 OR MIT |
| pkg-config | 0.3.32 | MIT OR Apache-2.0 |
| png | 0.18.1 | MIT OR Apache-2.0 |
| potential_utf | 0.1.2 | Unicode-3.0 |
| potential_utf | 0.1.4 | Unicode-3.0 |
| precomputed-hash | 0.1.1 | MIT |
| proc-macro2 | 1.0.106 | MIT OR Apache-2.0 |
| proc-macro2 | 1.0.95 | MIT OR Apache-2.0 |
| profiling | 1.0.16 | MIT OR Apache-2.0 |
| profiling-procmacros | 1.0.16 | MIT OR Apache-2.0 |
| pxfm | 0.1.27 | BSD-3-Clause OR Apache-2.0 |
| quick-error | 2.0.1 | MIT/Apache-2.0 |
| quote | 1.0.40 | MIT OR Apache-2.0 |
| quote | 1.0.44 | MIT OR Apache-2.0 |
| quote | 1.0.45 | MIT OR Apache-2.0 |
| radium | 0.7.0 | MIT |
| rand | 0.8.6 | MIT OR Apache-2.0 |
| rand_core | 0.6.4 | MIT OR Apache-2.0 |
| rawpointer | 0.2.1 | MIT/Apache-2.0 |
| rayon | 1.10.0 | MIT OR Apache-2.0 |
| rayon | 1.11.0 | MIT OR Apache-2.0 |
| rayon-core | 1.12.1 | MIT OR Apache-2.0 |
| rayon-core | 1.13.0 | MIT OR Apache-2.0 |
| rctree | 0.6.0 | MIT |
| regex | 1.12.2 | MIT OR Apache-2.0 |
| regex-automata | 0.4.13 | MIT OR Apache-2.0 |
| regex-syntax | 0.8.8 | MIT OR Apache-2.0 |
| rgb | 0.8.52 | MIT |
| roxmltree | 0.21.1 | MIT OR Apache-2.0 |
| rustc-demangle | 0.1.24 | MIT/Apache-2.0 |
| rustc-demangle | 0.1.27 | MIT/Apache-2.0 |
| rustc_version | 0.4.1 | MIT OR Apache-2.0 |
| safe_arch | 0.7.4 | Zlib OR Apache-2.0 OR MIT |
| scan_fmt | 0.2.6 | MIT |
| scopeguard | 1.2.0 | MIT OR Apache-2.0 |
| selectors | 0.31.0 | MPL-2.0 |
| semver | 1.0.27 | MIT OR Apache-2.0 |
| serde | 1.0.228 | MIT OR Apache-2.0 |
| serde_core | 1.0.228 | MIT OR Apache-2.0 |
| serde_derive | 1.0.228 | MIT OR Apache-2.0 |
| serde_json | 1.0.149 | MIT OR Apache-2.0 |
| serde_spanned | 1.0.4 | MIT OR Apache-2.0 |
| servo_arc | 0.4.3 | MIT OR Apache-2.0 |
| shlex | 1.3.0 | MIT OR Apache-2.0 |
| simba | 0.9.1 | Apache-2.0 |
| simd-adler32 | 0.3.8 | MIT |
| simd_helpers | 0.1.0 | MIT |
| siphasher | 1.0.2 | MIT/Apache-2.0 |
| slab | 0.4.11 | MIT |
| smallvec | 1.15.1 | MIT OR Apache-2.0 |
| stable_deref_trait | 1.2.0 | MIT/Apache-2.0 |
| stable_deref_trait | 1.2.1 | MIT OR Apache-2.0 |
| string_cache | 0.8.9 | MIT OR Apache-2.0 |
| string_cache | 0.9.0 | MIT OR Apache-2.0 |
| string_cache_codegen | 0.5.4 | MIT OR Apache-2.0 |
| syn | 2.0.102 | MIT OR Apache-2.0 |
| syn | 2.0.114 | MIT OR Apache-2.0 |
| syn | 2.0.117 | MIT OR Apache-2.0 |
| synstructure | 0.13.2 | MIT |
| system-deps | 7.0.7 | MIT OR Apache-2.0 |
| tap | 1.0.1 | MIT |
| target-lexicon | 0.13.3 | Apache-2.0 WITH LLVM-exception |
| tendril | 0.4.3 | MIT/Apache-2.0 |
| terminal_size | 0.4.2 | MIT OR Apache-2.0 |
| thiserror | 1.0.69 | MIT OR Apache-2.0 |
| thiserror | 2.0.12 | MIT OR Apache-2.0 |
| thiserror-impl | 1.0.69 | MIT OR Apache-2.0 |
| thiserror-impl | 2.0.12 | MIT OR Apache-2.0 |
| tinystr | 0.8.1 | Unicode-3.0 |
| tinystr | 0.8.2 | Unicode-3.0 |
| tinyvec | 1.10.0 | Zlib OR Apache-2.0 OR MIT |
| tinyvec | 1.11.0 | Zlib OR Apache-2.0 OR MIT |
| tinyvec_macros | 0.1.1 | MIT OR Apache-2.0 OR Zlib |
| toml | 0.9.11+spec-1.1.0 | MIT OR Apache-2.0 |
| toml_datetime | 0.7.5+spec-1.1.0 | MIT OR Apache-2.0 |
| toml_parser | 1.0.6+spec-1.1.0 | MIT OR Apache-2.0 |
| typenum | 1.19.0 | MIT OR Apache-2.0 |
| unicode-ident | 1.0.18 | (MIT OR Apache-2.0) AND Unicode-3.0 |
| unicode-ident | 1.0.22 | (MIT OR Apache-2.0) AND Unicode-3.0 |
| unicode-ident | 1.0.24 | (MIT OR Apache-2.0) AND Unicode-3.0 |
| unicode-width | 0.2.1 | MIT OR Apache-2.0 |
| url | 2.5.4 | MIT OR Apache-2.0 |
| url | 2.5.8 | MIT OR Apache-2.0 |
| utf-8 | 0.7.6 | MIT OR Apache-2.0 |
| utf8_iter | 1.0.4 | Apache-2.0 OR MIT |
| utf8parse | 0.2.2 | Apache-2.0 OR MIT |
| v_frame | 0.3.9 | BSD-2-Clause |
| vcpkg | 0.2.15 | MIT/Apache-2.0 |
| version-compare | 0.2.1 | MIT |
| web_atoms | 0.1.3 | MIT OR Apache-2.0 |
| weezl | 0.1.12 | MIT OR Apache-2.0 |
| wide | 0.7.33 | Zlib OR Apache-2.0 OR MIT |
| winapi | 0.3.9 | MIT/Apache-2.0 |
| winapi-x86_64-pc-windows-gnu | 0.4.0 | MIT/Apache-2.0 |
| windows-link | 0.2.1 | MIT OR Apache-2.0 |
| windows-sys | 0.59.0 | MIT OR Apache-2.0 |
| windows-sys | 0.60.2 | MIT OR Apache-2.0 |
| windows-targets | 0.52.6 | MIT OR Apache-2.0 |
| windows-targets | 0.53.5 | MIT OR Apache-2.0 |
| windows_x86_64_gnu | 0.52.6 | MIT OR Apache-2.0 |
| windows_x86_64_gnu | 0.53.1 | MIT OR Apache-2.0 |
| winnow | 0.7.14 | MIT |
| writeable | 0.6.1 | Unicode-3.0 |
| writeable | 0.6.2 | Unicode-3.0 |
| wyz | 0.5.1 | MIT |
| xml5ever | 0.35.0 | MIT OR Apache-2.0 |
| y4m | 0.8.0 | MIT |
| yoke | 0.8.0 | Unicode-3.0 |
| yoke | 0.8.1 | Unicode-3.0 |
| yoke-derive | 0.8.0 | Unicode-3.0 |
| yoke-derive | 0.8.1 | Unicode-3.0 |
| zerofrom | 0.1.6 | Unicode-3.0 |
| zerofrom-derive | 0.1.6 | Unicode-3.0 |
| zerotrie | 0.2.2 | Unicode-3.0 |
| zerotrie | 0.2.3 | Unicode-3.0 |
| zerovec | 0.11.2 | Unicode-3.0 |
| zerovec | 0.11.5 | Unicode-3.0 |
| zerovec-derive | 0.11.1 | Unicode-3.0 |
| zerovec-derive | 0.11.2 | Unicode-3.0 |
| zmij | 1.0.21 | MIT |
| zune-core | 0.5.1 | MIT OR Apache-2.0 OR Zlib |
| zune-jpeg | 0.5.13 | MIT OR Apache-2.0 OR Zlib |
